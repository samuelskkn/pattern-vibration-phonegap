# Pattern-Vibration-Phonegap
This is Phonegap app to vibrate with some patterns. 
